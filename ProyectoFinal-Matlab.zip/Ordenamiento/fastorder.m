function v = fastorder(v)
    if length(v)>1
        kleft=0; %Auxiliar variable to avoid zeros in vleft.
        kright=0;
        vleft=[];%Leftside array.
        vright=[];
        for i=2:length(v)
            if v(1)>v(i)
                kleft=kleft+1;
                vleft(kleft)=v(i);
            else
                kright=kright+1;
                vright(kright)=v(i);
            end
        end
        v = [fastorder(vleft) v(1) fastorder(vright)];
    else
        v=v;
    end
end