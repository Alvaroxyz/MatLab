%This function receives a vector as its unique input and returns the mean
%of the elements of such array. For instance, miprom([2 2 5])=3.
function miu = miprom(x)
    if nargin==1
        miu = misum(x)/length(x);
    else
        warning('The function miprom() needs only one input.')
        miu=0;
    end
end