%%The function mimax() receives at most two input parameters.
%If A is a vector, mimax(A) returns the greatest element of such vector.
%If A is a matrix, mimin(A) returns a vector whose elements are the
%greatest elements of each column of A.
%If A is a matrix, mimin(A,2) returns the greatest elements for each row of
%A.
function vmax = mimax(A,row)
    sizeofA=size(A);
    i=1;
    if (nargin==1 && sizeofA(1)~=1 && sizeofA(2)~=1)
        vmax=zeros(1,sizeofA(2));
        while i<=sizeofA(2)
            aux=fastorder(A(:,i));
            vmax(i)=aux(sizeofA(1));
            i=i+1;
        end
    elseif (nargin==1 && sizeofA(1)==1)
        aux=fastorder(A);
        vmax=aux(sizeofA(2));
    elseif(nargin==1 && sizeofA(2)==1)
        aux=fastorder(A');
        vmax=aux(sizeofA(1));
    elseif (nargin==2 && row==2)
        while i<=sizeofA(1)
            aux=fastorder(A(i,:));
            vmax(i)=aux(sizeofA(2));
            i=i+1;
        end
    else
        warning('Error')
    end
end