%The function mimin() receives at most two input parameters.
%If A is a vector, mimin(A) returns the minimum element of such vector.
%If A is a matrix, mimin(A) returns a vector whose elements are the
%minimums elements of each column of A.
%If A is a matrix, mimin(A,2) returns the minimum elements for each row of
%A.
function vmin = mimin(A,row)
    sizeofA=size(A);
    i=1;
    if (nargin==1 && sizeofA(1)~=1 && sizeofA(2)~=1)
        vmin=zeros(1,sizeofA(2));
        while i<=sizeofA(2)
            aux=fastorder(A(:,i));
            vmin(i)=aux(1);
            i=i+1;
        end
    elseif (nargin==1 && sizeofA(1)==1)
        aux=fastorder(A);
        vmin=aux(1);
    elseif(nargin==1 && sizeofA(2)==1)
        aux=fastorder(A');
        vmin=aux(1);
    elseif (nargin==2 && row==2)
        while i<=sizeofA(1)
            aux=fastorder(A(i,:));
            vmin(i)=aux(1);
            i=i+1;
        end
    else
        warning('Error')
    end
end