%The function conteo() receives as input a number n and returns the
%divisors of this. For instance, conteo(6) returns 4.
function ndiv = conteo(n)
    i=1;
    ndiv=0;
    while i<=n
        if mod(n,i)==0
            ndiv=ndiv+1;
        end
        i=i+1;
    end
end