%The function divisores() receives only one input argument, a number n, and
%returns a vector which contains the positive integer divisors of n.
function divofn = divisores(n)
    i=1;
    divofn=zeros(1,conteo(n));
    k=1;
    while i<=n
        if mod(n,i)==0
            divofn(k)=i;
            k=k+1;
        end
        i=i+1;
    end
end