%This function captures two inputs: a vector and a boolean variable.
%misum(v) returns the sum of the elements of v.
%misum(v,1) returns the sum of the even elements of v.
%misum(v,0) returns the sum of the odd elements of v.
function S = misum(v,OddSum)
    S=0;
    if nargin==1        
        i=1;
        while(i<=length(v))
            S=S+v(i);
            i=i+1;
        end        
    elseif nargin==2
        if OddSum==false
            i=1;
            while(i<=length(v))
                if mod(v(i),2)==1
                    S=S+v(i);
                end
                i=i+1;
            end
        else
            i=1;
            while(i<=length(v))
                if mod(v(i),2)==0
                    S=S+v(i);
                end
                i=i+1;
            end
        end
    else
        warning('The function misum() must have at least one input.')
    end
end