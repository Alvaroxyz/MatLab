%This function receives one or two inputs.
%misumA(X) returns the sum of the elements of each column of X.
%misumA(X,2) returns the sum of the elements of each row of X.
function S = misumA(A,rows)
    sizeofA=size(A);
    m=sizeofA(1);
    n=sizeofA(2);    
    i=1;
    if nargin==1
        S=zeros(1,n);
        while i<=n
            S(i)=misum(A(:,i));
            i=i+1;
        end
    elseif nargin==2
        S=zeros(1,m);
        if rows==2
            while i<=m
                S(i)=misum(A(i,:));
                i=i+1;
            end
        end
    else
        warning('The function misumA() needs at least two inputs.')
    end
end