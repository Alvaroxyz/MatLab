%The function perfecto() receives only one input argument, a given number
%n. If the number is perfect, then the function returns 1, if not returns
%0.
function isperfect = perfecto(n)
    divofn=divisores(n);
    if n==sum(divofn(1,1:length(divofn)-1))
        isperfect=true;
    else
        isperfect=false;
    end
end