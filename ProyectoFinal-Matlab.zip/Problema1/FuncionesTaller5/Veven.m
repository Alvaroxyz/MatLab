%The function Veven(x) receives a vector x and returns a new vector such
%that its elements are the even elements of x.
function v = Veven(x)
    i=1;
    aux=1;
    v=[];
    while i<=length(x)
        if mod(x(i),2)==0
            v(aux)=x(i);
            aux=aux+1;
        end
        i=i+1;
    end
end