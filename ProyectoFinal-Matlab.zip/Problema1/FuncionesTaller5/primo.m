%The function primo() receives one number n as input argument and returns two
%outputs: 1 if the number is prime and a vector with the numbers primes between 1 and n.
%For instance, primo(15) returns 0 and [2,3,5,7,11,13].
function [isp,p2n] = primo(n)
    if conteo(n)==2
        isp=true;
    else
        isp=false;
    end
    i=1;
    k=1;
    while i<=n
        if conteo(i)==2
            p2n(k)=i;
            k=k+1;
        end
        i=i+1;
    end
end