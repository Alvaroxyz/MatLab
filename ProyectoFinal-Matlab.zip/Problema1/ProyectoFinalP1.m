%{
------------------------TRABAJO FINAL-PROBLEMA1------------------------------
A continuacion encontrara 10 ejercicios solucionados del taller 5.
%}
%{
EJERCICIO 1---------------------------------------------------------------
En este programa utilizamos la funcion misum() para calcular la suma de
un vector dado.
%}
tic
s=misum(1:10000);
toc
tic
SMatlab=sum(1:1000);
toc
%%
%{
EJERCICIO 2---------------------------------------------------------------
Este programa verifica el funcionamiento de la funcion misum(). Para mas
informacion consulte >>help misum.
%}
S=misum(1:100,0);
s2=sum(1:2:100);
s3=misum();
%%
%{
EJERCICIO 3---------------------------------------------------------------
Este programa emplea la funcion miprom() para obtener el promedio de los
valores de los elementos de un vector dado. Para mas informacion consulte
>>help miprom.
%}
media=miprom([5 4.7 5 5]);
media=miprom();
%%
%{
EJERCICIO 4---------------------------------------------------------------
Este programa implementa la funcion misumA() la cual simula lo que hace la
funcion sum() de MATLAB. Para mas informacion consulte >>help misumA().
%}
A=[1 2 3;2 4 7];
misumA(A)
%%
%{
EJERCICIO 5---------------------------------------------------------------
Este programa implementa la funcion Veven() la cual devuele un vector con
los elementos pares de un vector dado. Para mas informacion consulte >>help
Veven.
%}
x=1:50;
xeven=Veven(x);
%%
%{
EJERCICIO 7---------------------------------------------------------------
Programa para simular las funciones max() y min() de MATLAB. Para mas
informacion consulte >>help mimax() y >>help mimin()
%}
v=[4 7 8 33 1];
M=[2 3 4;70 20 80;1 2 100];
mimax(v)
mimin(v)
mimax(M)
mimax(M,2)
mimin(M)
mimin(M,2)
%%
%{
EJERCICIO 17
Este programa emplea la funcion conteo() para calcular el numero de
divisores enteros positivos de un numero dado n. Para mas informacion,
consulte >>help conteo.
%}
k=conteo(11);
%%
%{
EJERCICIO 18
Este programa emplea la funcion primo(). Para mas informacion consulte
>>help primo.
%}
[isprimo p215]=primo(15);
%%
%{
EJERCICIO 20
Este programa permite calcular todos los divisores enteros positivos 
de un numero n dado.
%}
v=divisores(12);
%%
%{
EJERCICIO 21
Este programa permite saber cuando un numero dado n es un numero perfecto.
%}
perfecto(28)