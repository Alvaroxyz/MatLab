%The function games has three input arguments. The first one is the kind of
%game: 1 is the four corners, 2 is the main diagonal, 3 is the second diagonal, 4 is
% the horizontal, 5 is the vertical and 6 is the big cross.
%The second one is the matrix that contains the N cards.
%The last one is a vector that indicates the cards in play.
%The function retuns a matrix with the game typed for each of the cards in
%play. For instance, games(1,M,[1 2 3]) returns a matrix Y whose rows are
%the four corners for cards 1,2 and 3, respectively.
function Y = games(ngame,M,ncards)
    vaux=size(M);
    if length(ncards) > vaux(3)
        warning('The cards in play are greater than the total of cards.')
    else
        switch ngame
            case 1
                Y=fourcorners(M,ncards);
            case 2
                Y=maindiagonal(M,ncards);
            case 3
                Y=secondDiag(M,ncards);
            case 4
                Y=hgame(M,ncards);
            case 5
                Y=vgame(M,ncards);
            case 6
                Y=bigcross(M,ncards);
            otherwise
                warning('The games are from 1 to 6.')
        end
    end
end