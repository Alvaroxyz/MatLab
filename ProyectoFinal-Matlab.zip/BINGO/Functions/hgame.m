function H = hgame(M, ncards)
    H=zeros(length(ncards),5);
    k=1;
    while k<=length(ncards)
        H(k,:)=M(3,:,ncards(k));
        k=k+1;
    end
    H=[H(:,[1 2]) H(:,[4 5])];
end