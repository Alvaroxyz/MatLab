%This function has one input N, which stands for the number of cards and
%can return two hypermatrices. The variable B is a hypermatrix with the N
%cards and A is another one with only the numbers that contains each card.
function [B,M] = bingocards(N)    
    [B,M]=card(6,5);        
    i=2;
    while i<=N
        [B(:,:,i),M(:,:,i)]=card(6,5);
        i=i+1;
    end   
end