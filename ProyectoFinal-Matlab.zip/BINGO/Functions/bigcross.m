function X = bigcross(M,ncards)
    X1=maindiagonal(M,ncards);
    X2=secondDiag(M,ncards);
    X=[X1 X2];
end