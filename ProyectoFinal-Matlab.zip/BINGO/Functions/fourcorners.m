function Y1 = fourcorners(M,ncards)
    i=1;
    Y1=zeros(length(ncards),4);
    while i<=length(ncards)
        Y1(i,:)=reshape(M([1 5],[1 5],ncards(i))',1,[]);
        i=i+1;
    end
end