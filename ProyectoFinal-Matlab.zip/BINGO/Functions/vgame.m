function V = vgame(M, ncards)
    V=zeros(length(ncards),5);
    k=1;
    while k<=length(ncards)
        V(k,:)=M(:,3,ncards(k))';
        k=k+1;
    end
    V=[V(:,[1 2]) V(:,[4 5])];
end