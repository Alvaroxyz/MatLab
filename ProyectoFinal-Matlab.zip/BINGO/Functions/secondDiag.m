%The function secondDiag(M,ncards) works analogously to
%maindiagonal(M,ncards). The difference is that the first returns a matrix
%whose rows have the elements of the secondary diagonals for each
%participating card.
function D2 = secondDiag(M,ncards)
    k=1;
    while k<=length(ncards)
        M(:,:,ncards(k))=rot90(M(:,:,ncards(k)),3);
        k=k+1;
    end
    D2=maindiagonal(M,ncards);
end