%The function maindiagonal(M,ncards) has as inputs the hypermatrix M with
%all cards and the array ncards to indicate the participate cards. The output is 
%a matrix of size length(ncards)-by-4 where each row contain the elements of 
% the main diagonal for each playing card. For instance, maindiagonal(M,[1
% 3 5]) returns a 3-by-4 matrix whose element of each row are the elements
% of the diagonals of cards 1, 3 and 5. 
function Dm = maindiagonal(M,ncards)
    i=1;
    Dm=zeros(length(ncards),5);
    while i<=length(ncards)
        x=diag(M(:,:,ncards(i)));
        Dm(i,:)=x';
        i=i+1;
    end
    Dm=[Dm(:,[1 2]) Dm(:,[4 5])];
end
%{
    Dm=zeros(length(ncards),4);
    i=1;
    j=1;   
    while j<=5
        while i<=length(ncards)
            if (j~=3)
                Dm(i,j)=M(j,j,ncards(i));                
            end
            i=i+1;
        end
        j=j+1;
        i=1;
    end
    Dm=[Dm(:,[1 2]) Dm(:,[4 5])];
%}
