%This function receives two input arguments: n and m. The numbers n and m
%are the rows and columns of the card, respectively. The output are tow
%hypermatrices: B stands for the card and M has only the numbers of B.
function [B,M] = card(n,m)
    M=zeros(5);
    x0=15;
    k=0;
    while k<=4 
        M(:,k+1)=randperm(15,5)+k*x0; %For creating the numbers of the card.
        k=k+1;
    end
    B=cell(n,m); %For the original bingo card
    B(1,:)={'B','I','N','G','O'}; 
    j=1;
    i=2;
    while j<=m
        while i<=n
            B(i,j)={M(i-1,j)}; %Add the elementos of M to B.
            i=i+1;
        end
        j=j+1;
        i=2;
    end
    B(4,3)={':)'};        
end