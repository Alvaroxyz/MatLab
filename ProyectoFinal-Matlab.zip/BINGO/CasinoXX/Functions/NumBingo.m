function Fnumbers = NumBingo(M)
    fun = @(k)M(:,:,k);
    C=arrayfun(fun,1:30,'UniformOutput',0); %Concatena las salidas de fun, las cuales son los cartones, en un array de tipo cell.
    Mgrande=vertcat(C{:});%Contaneacion de C para que aparezcan todos los cartones concatenados de manera vertical
    for i=3:5:148 %Quitar el elmento central de cada carton.
        Mgrande(i,3)=NaN;
    end
    Fnumbers = zeros(1,5);
    j=1;
    while j<=5
        Fnumbers(j)=mode(Mgrande(:,j)); %Para saber el numero mas frecuente.
        j=j+1;
    end
end