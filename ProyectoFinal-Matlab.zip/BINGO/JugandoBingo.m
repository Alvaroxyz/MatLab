clc
button=1;
while button == 1
    disp('********************Bienvenido al Juego del Bingo********************')
    button = input('Ingrese uno para empezar o cero para salir: ');
    if button == 0
        disp('Gracias por jugar.')
        pause(1)
        clc
        break
    else
        clc
        players = input('Digite el numero de jugadores a participar: ');
        pause(1)
        clc
        cardsperply = zeros(1,players); %Numero de cartones/jugador
        for i=1:players
            message = sprintf('Hola participante %d',i);
            disp(message)
            cardsperply(i) = input('Ingrese la cantidad de cartones para jugar: ');
            while cardsperply(i)>5
                warning('Ups. El maximo numero de cartones es 5.')
                pause(2)
                clc
                cardsperply(i) = input('Ingrese nuevamente la cantidad de cartones para jugar: ');            
            end
            pause(2)
            clc
        end        
        [B,M] = bingocards(sum(cardsperply));%Generando los cartones
        i=1;
        j=1;
        suma=0;
        while i<=length(cardsperply) 
            suma=suma+cardsperply(i);
            disp(['A continuacion los cartones del jugador ',num2str(i),':'])
            disp(B(:,:,j:suma))
            pause        
            j=suma+1;
            i=i+1;
        end
        clc
        disp('Tipo de Jugadas.')
        disp('1 es cuatro esquinas.')
        disp('2 es diagonal principal.')
        disp('3 es diagonal secundaria.')
        disp('4 es horizontal.')
        disp('5 es verical.')
        disp('6 es x o cruz.')
        ngame = input(['Todos los participantes competiran en el tipo de jugada que se escoga.' ...
            ' Ingrese el numero de jugada: ']);
        clc
        G = games(ngame,M,1:sum(cardsperply)); %numeros de interes/jugada seleccionada
        aleatorios = randperm(75);
        [w,wply,time] = winner(B,G,aleatorios);%wply para almacenar el ganador, time para la ultima balota que se obtiene.
        disp('Las balotas se muestran a continuacion:')
        disp(aleatorios(1:time))        
        disp('El carton ganador es: ')
        disp(B(:,:,wply))
        c=0;
        ply = 1;
        for i=1:sum(cardsperply)
            c=c+1;
            if i==wply
                disp(['Y el jugador ganador es: ',num2str(ply),'.'])
                break;
            end
            if c==cardsperply(ply)
                ply=ply+1;
                c=0;
            end
        end        
    end
    button = input('Si desea volver a jugar, ingrese 1. Si desea salir, digite 0: ');
    clc
    if button==0
        disp('Gracias por jugar.')
        pause(1)
        clc
        break
    end
end